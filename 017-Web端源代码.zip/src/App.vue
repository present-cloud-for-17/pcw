<template>
    <div id="app">
        <router-view></router-view>
    </div>
</template>
<style>
    @import "./shared/components/assets/css/main.css";
    @import "./shared/components/assets/css/color-dark.css";     /*深色主题*/
    /*@import ".//shared/componentsassets/css/theme-green/color-green.css";   浅绿色主题*/
</style>